package college_management_system_itamar_cohen;

import java.util.Scanner;

import college_management_system_itamar_cohen.College.eCommitteStatus;
import college_management_system_itamar_cohen.Lecturer.eDegree;


public class Main {
	private static Scanner scanner = new Scanner(System.in);
	
	public static void printMenu() {
	    System.out.println("Menu:\n"
	        + "  0 - Exit\n"
	        + "  1 - Add Lecturer to college\n"
	        + "  2 - Add Committee to college\n"
	        + "  3 - Add member to Committee\n"
	        + "  4 - Update head of committee\n"
	        + "  5 - Remove a member from committee\n"
	        + "  6 - Add new department\n"
	        + "  7 - Display the average salary of all lecturers in the college\n"
	        + "  8 - Display the average salary of all lecturers in a specific department\n"
	        + "  9 - Display the full details of all lecturers\n"
	        + " 10 - Display the full details of all committees\n"
	        + " 11 - Add a Member To Department\n"
	        + " 12 - Compare between Dr./Professors by their number of published articles\n"
	        + " 13 - Compare between Departments by number of lecturers or total articles of their lecturers\n"
	        + " 14 - Duplicate an existing committee\n"
	        + "Enter your option number:\n");
	
	}

	
	public static void addLecturerToCollege(College myCollege) {
		System.out.println("Please enter the name of your lecturer:");
		String lecturerName = scanner.nextLine();
        System.out.println("Please enter the id of your lecturer:");
        int lecturerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Please enter the lecturer's degree:"); // (BACHELOR, MASTER, DOCTORATE, PROFESSOR):");
        Lecturer.eDegree [] allDegrees = Lecturer.eDegree.values();
        for (int i = 0; i < allDegrees.length; i++ ) {
        	System.out.println((allDegrees[i].ordinal()+1) + ") " + allDegrees[i].name());
        }
        System.out.println("--->");
        Lecturer.eDegree lecturerDegree = Lecturer.eDegree.valueOf(scanner.nextLine().toUpperCase());
        System.out.println("Please enter the degree's name of your lecturer:");
        String lectuerDgreeName = scanner.nextLine();
        String professorTitleFrom = null;
        if (lecturerDegree == Lecturer.eDegree.PROFESSOR) {
            System.out.println("Enter the name of the institution that granted the Professorship:");
            professorTitleFrom = scanner.nextLine();
        }
        

        String[] articles = null;
     // הוספת מאמרים אם המרצה הוא ד"ר או פרופסור
        if (lecturerDegree == Lecturer.eDegree.DOCTORATE || lecturerDegree == Lecturer.eDegree.PROFESSOR) {
            System.out.println("How many articles would you like to enter?");
            int numArticles = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            articles = new String[numArticles];
            for (int i = 0; i < numArticles; i++) {
                System.out.println("Enter article #" + (i + 1) + ":");
                String articleTitle = scanner.nextLine();
                articles[i]=articleTitle;
            }
        }
        System.out.println("Please enter the salary of your lecturer:");
        int lecturerSalary = scanner.nextInt();	          
        myCollege.addLecturer(lecturerName, lecturerId, lecturerDegree, lectuerDgreeName, lecturerSalary,professorTitleFrom,articles);
	}
	
	public static void addCommitteeToCollege(College myCollege) {
		System.out.println("Please enter the name of your committee:");
	    String committeeName = scanner.nextLine();
	    System.out.println("Please enter the name of your head of committee:");
        String headOfCommitte = scanner.nextLine();
        try {
            myCollege.addCommittee(committeeName, headOfCommitte);
            System.out.println("Committee added successfully!");
        } catch (CommitteeAlreadyExistsException | LecturerNotFoundException | LecturerUnqualifiedException e) {
            System.out.println("Failed to add committee: " + e.getMessage());
        }
        
    }
    	
	public static void addMemberToCommittee(College myCollege) {
    	System.out.println("Please enter the name of your committee:");
	    String committeeName = scanner.nextLine();
	    System.out.println("Please enter the name of your lecturer:");
        String lecturerName = scanner.nextLine();
        myCollege.assignLecturerToCommittee(lecturerName, committeeName);
	}

	public static void updateHeadOfCommittee(College myCollege) {
        System.out.println("Please enter the name of your committee:");
	    String committeeName = scanner.nextLine();
	    System.out.println("Please enter the name of your lecturer:");
        String lecturerName = scanner.nextLine();
        try {
        	myCollege.setHeadOfCommittee(lecturerName,committeeName);
        } catch (LecturerNotFoundException | CommitteeNotFoundException |
                 LecturerAlreadyInCommitteeException | LecturerUnqualifiedException e) {
            System.out.println("Error: " + e.getMessage());
        }

	}
	
	public static void removeMemberFromCommittee(College myCollege) {
        System.out.println("Please enter the name of your committee:");
	    String committeeName = scanner.nextLine();
	    System.out.println("Please enter the name of your lecturer:");
        String lecturerName = scanner.nextLine();
        myCollege.removeMemberFromCommittee(lecturerName, committeeName);
	}
	
	public static void addDepartmentToCollege(College myCollege) {
        System.out.println("Please enter the name of your department:");
	    String departmentName = scanner.nextLine();
        System.out.println("Please enter the number of students in your department:");
        int numStudents = scanner.nextInt();	                 	
        myCollege.addDepartment(departmentName, numStudents);

	}
	
	public static void addMemberToDepartment(College myCollege) {
    	System.out.println("Please enter the name of your Department:");
	    String departmentName = scanner.nextLine();
	    System.out.println("Please enter the name of your lecturer:");
        String lecturerName = scanner.nextLine();
        myCollege.assignLecturerToDepartment(lecturerName, departmentName);

	}
	
	public static double averageSalaryAllLecturersInSpecificDepartment(College myCollege) {
        double result=0;
        System.out.println("Please enter the name of your department:");
	    String departmentName = scanner.nextLine();
	    Department specificDepartment=myCollege.findDepartmentByName(departmentName);
		Lecturer allLecturers[]=specificDepartment.getLecturers();
		for (int i = 0; i < allLecturers.length; i++) {
			result =result+ allLecturers[i].getSalary();
		}
		result=result/allLecturers.length;
        return result;
	}
	
	public static void compareTwoLecturersByNumberOfArticles(College myCollege) {
		System.out.println("Enter the name of the first lecturer:");
		String lecturerName1 = scanner.nextLine();
		System.out.println("Enter the name of the second lecturer:");
		String lecturerName2 = scanner.nextLine();
		myCollege.compareTwoLecturersByNumberOfArticles(lecturerName1,lecturerName2);
        return;
	}
	
	public static void compareTwoCommittees(College myCollege) {

		System.out.println("Enter first committee name:");
		String com1 = scanner.nextLine();
		System.out.println("Enter second committee name:");
		String com2 = scanner.nextLine();
		System.out.println("Choose criteria to compare:\n1) Number of lecturers\n2) Total number of articles");
		int criteria = scanner.nextInt();
		scanner.nextLine();
	
		myCollege.compareTwoCommittees(com1, com2, criteria);
	}
	
	public static void duplicateCommittee(College myCollege) {

		System.out.println("Enter the name of the committee to duplicate:");
        String originalCommitteeName = scanner.nextLine();
        myCollege.duplicateCommittee(originalCommitteeName);
	}
	
    public static void main (String[] args) {
        System.out.println("Enter the name of your college:");
        String collegeName = scanner.nextLine();
        College myCollege=new College(collegeName);
        printMenu();
        int menuAns = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        while (menuAns != 0) {
            switch (menuAns) {
                case 1:
                	//	"1 - Add Lecturer to college"
                	addLecturerToCollege(myCollege);
                    break;

                case 2:
            		//+ "2 - Add Committee to college\n"
                	addCommitteeToCollege(myCollege);
                    break;

                case 3:
            		//+ "3 - Add member to Committee\n"
                	addMemberToCommittee(myCollege);
                    break;

                case 4:
            		//+ "4 - update head of committee\n"
                	updateHeadOfCommittee(myCollege);
        	        break;

                case 5:
            		//+ "5 - Remove a member from committee\n"
                	removeMemberFromCommittee(myCollege);
                    break;

                case 6:
            		//+ "6 - add new department \n"
                	addDepartmentToCollege(myCollege);
                    break;

                case 7:
            		//+ "7 - Display the average salary of all lecturers in the college.\n"
                	double averageSalary=myCollege.averageSalaryAllLecturersInTheCollege();
                    System.out.println("Average salary of all lecturers is:" + averageSalary);
                    break;

                case 8:
            		//+ "8 - Display the average salary of all lecturers in a specific department\n"
                	double averageSalaryInDepartment=averageSalaryAllLecturersInSpecificDepartment(myCollege);
                    System.out.println("Average salary of all lecturers in a this department is:" + averageSalaryInDepartment);
                    break;

                case 9:
            		//+ "9 - Display the full details of all lecturers."
                	myCollege.fullDetailsOfAllLecturers();
                    
                    break;

                case 10:
            		//+ "10 - Display the full details of all committees"
                	myCollege.fullDetailsOfAllCommittees();
                    
                    break;
                    
                case 11:
            		//+ "11 - Add a Member To Department"
                	addMemberToDepartment(myCollege);
                    break;
                    
                case 12:
                    // 12 - Compare between Dr./Professors by their number of published articles
                    compareTwoLecturersByNumberOfArticles(myCollege);
                    break;

                case 13:
                    // 13 - Compare between Committees by number of lecturers or total articles of their lecturers
                   
                	compareTwoCommittees(myCollege);
                    break;

                case 14:
                    // 14 - Duplicate an existing committee
                    
                    duplicateCommittee(myCollege);
                    break;
                    
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
            
            printMenu();
            menuAns = scanner.nextInt();
            scanner.nextLine(); // Consume newline
        }
        System.out.println("goodbye :)");
    

    }
}