package college_management_system_itamar_cohen;

public class Committee {
	private String name;
	private Lecturer headOfCommittee;
	private Lecturer[] allLecturers;
	private int numOfLecturers;

	public Committee(String name, Lecturer headOfCommittee) {
		setName(name);
		setHeadOfCommittee(headOfCommittee);
		allLecturers = new Lecturer[10];
		numOfLecturers = 0;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Lecturer getHeadOfCommittee() {
		return headOfCommittee;
	}

	public void setHeadOfCommittee(Lecturer headOfCommittee) {
	    this.headOfCommittee = headOfCommittee;
	}

	public boolean addLecturer(Lecturer theLecturer) {
		if (headOfCommittee != null && headOfCommittee.equals(theLecturer)) {
			return false;
		}
		for (int i = 0; i < numOfLecturers; i++) {
			if (allLecturers[i] != null && allLecturers[i].equals(theLecturer)) {
				return false;
			}
		}
		if (numOfLecturers == allLecturers.length) {
			Lecturer[] temp = new Lecturer[allLecturers.length * 2];
			for (int i = 0; i < allLecturers.length; i++)
				temp[i] = allLecturers[i];
			allLecturers = temp;
		}
		allLecturers[numOfLecturers++] = theLecturer;
		theLecturer.addCommittee(this);
		return true;
	}
	
	public boolean removeLecturer(Lecturer theLecturer) {
		for (int i = 0; i < numOfLecturers; i++) {
			if (allLecturers[i] != null && allLecturers[i].equals(theLecturer)) {
				for (int j = i; j < numOfLecturers - 1; j++) {
					allLecturers[j] = allLecturers[j + 1];
				}
				allLecturers[numOfLecturers - 1] = null;
				numOfLecturers--;
				theLecturer.removeCommittee(this); // remove back reference
				return true;
			}
		}
		return false;
	}
	
	public Lecturer[] getLecturers() {
		Lecturer[] result = new Lecturer[numOfLecturers];
		for (int i = 0; i < numOfLecturers; i++) {
			result[i] = allLecturers[i];
		}
		return result;
	}
	
	public boolean equals(Object obj) {
	    if (this == obj) return true;
	    if (obj == null || getClass() != obj.getClass()) return false;

	    Committee other = (Committee) obj;

	    // נניח שהשם מזהה את הוועדה – אפשר להרחיב בהמשך
	    return this.name != null && this.name.equals(other.name);
	}

	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("Committee '" + name + "' headed by " + headOfCommittee.getName() + " has the following memeber"
				+ (numOfLecturers > 1 ? "s:" : ":") + "\n");
		for (int i = 0; i < numOfLecturers; i++) {
			str.append((i + 1) + "- " + allLecturers[i].getName() + "\n");
		}
		return str.toString();
	}

}