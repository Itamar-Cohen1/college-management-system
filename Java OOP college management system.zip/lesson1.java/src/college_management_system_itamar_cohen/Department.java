package college_management_system_itamar_cohen;

public class Department {
		private String name;
		private int numOfStudents;
		private Lecturer[] allLecturers;
		private int numOfLecturer;

		public Department(String name, int numOfStudents) {
			this.name = name;
			setNumOfStudents(numOfStudents);
			allLecturers = new Lecturer[10];
			numOfLecturer = 0;
		}
		
		public String getName() {
			return name;
		}

		public void setNumOfStudents(int numOfStudents) {
			this.numOfStudents = numOfStudents;
		}

		public int getNumOfStudents() {
			return numOfStudents;
		}

		public boolean addLecturer(Lecturer theLecturer) {
			if (theLecturer.getDepartment() != null) {
				return false;
			}
			for (int i = 0; i < numOfLecturer; i++) {
				if (allLecturers[i] != null && allLecturers[i].equals(theLecturer)) {
					return false;
				}
			}
			if (numOfLecturer == allLecturers.length) {
				Lecturer[] temp = new Lecturer[allLecturers.length * 2];
				for (int i = 0; i < allLecturers.length; i++)
					temp[i] = allLecturers[i];
				allLecturers = temp;
			}
			allLecturers[numOfLecturer++] = theLecturer;
			theLecturer.setDepartment(this);
			return true;
		}

		public Lecturer[] getLecturers() {
			Lecturer[] result = new Lecturer[numOfLecturer];
			for (int i = 0; i < numOfLecturer; i++) {
				result[i] = allLecturers[i];
			}
			return result;
		}

		public boolean equals(Object obj) {
		    if (this == obj) return true;
		    if (obj == null || getClass() != obj.getClass()) return false;

		    Department other = (Department) obj;

		    return this.name != null && this.name.equals(other.name);
		}
		
		public String toString() {
			StringBuffer str = new StringBuffer();
			str.append(
			"department '" + name + "' has " + numOfStudents + " student" + (numOfStudents > 1 ? "s" : "") + "\n");
			for (int i = 0; i < numOfLecturer; i++) {
				str.append((i + 1) + "- " + allLecturers[i].getName() + "\n");
			}
			return str.toString();
		}

	}