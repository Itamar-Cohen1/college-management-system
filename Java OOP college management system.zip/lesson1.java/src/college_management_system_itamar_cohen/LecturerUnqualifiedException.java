package college_management_system_itamar_cohen;

public class LecturerUnqualifiedException extends Exception {
    public LecturerUnqualifiedException(String message) {
        super(message);
    }
}

