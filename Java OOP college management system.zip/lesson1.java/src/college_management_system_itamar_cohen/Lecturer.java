package college_management_system_itamar_cohen;

public class Lecturer {
public enum eDegree{BACHELOR,MASTER,DOCTORATE,PROFESSOR };
	
	private String name;
	private int id;
	private eDegree degree; // Bachelor's, Master's, Dr, Prof
	private String degreeName;
	private double salary;
	private Department department;
	private Committee[] allCommittees;
    private int numOfCommittees;
    private String[] articles;
    private int numOfArticles;
	private String professorTitleFrom;

	public Lecturer(String name, int id, eDegree degree, String degreeName, double salary, String professorTitleFrom,String[] articles) {
	    setName(name);
	    setId(id);
	    setDegree(degree);
	    setDegreeName(degreeName);
	    setSalary(salary);
	    allCommittees = new Committee[2];
	    numOfCommittees = 0;

	    if (degree == eDegree.DOCTORATE || degree == eDegree.PROFESSOR) {
	        this.articles = articles;
	        numOfArticles = articles.length;
	    }

	    if (degree == eDegree.PROFESSOR) {
	        this.professorTitleFrom = professorTitleFrom;
	    }
	}

	public Lecturer(Lecturer other) {
        setName(other.name);
        setId(other.id);
        setDegree(other.degree);
        setDegreeName(other.degreeName);
        setSalary(other.salary);
        this.department = other.department;
        allCommittees = new Committee[10];
        numOfCommittees = 0;
        if (degree == eDegree.DOCTORATE || degree == eDegree.PROFESSOR) {
            articles = new String[other.articles.length];
            for (int i = 0; i < other.numOfArticles; i++) {
                articles[i] = other.articles[i];
            }
            numOfArticles = other.numOfArticles;
        }
        if (degree == eDegree.PROFESSOR) {
            professorTitleFrom = other.professorTitleFrom;
        }
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public eDegree getDegree() {
		return degree;
	}

	public void setDegree(eDegree degree) {
		this.degree = degree;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}
	
	public void setProfessorTitleFrom(String professorTitleFrom) {
		this.professorTitleFrom = professorTitleFrom;
	}
	 
	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Department getDepartment() {
		return department;
	}
	public String getProfessorTitleFrom() {
        return professorTitleFrom;
    }
	public void setDepartment(Department department) {
		this.department = department;
	}

	public boolean addCommittee(Committee theCommittee) {
		if (theCommittee == null || theCommittee.getName() == null) {
			return false;
		}
		for (int i = 0; i < numOfCommittees; i++) {
			if (allCommittees[i] != null && allCommittees[i].equals(theCommittee)) {
				return false; // already exists
			}
		}
		if (numOfCommittees == allCommittees.length) {
			Committee[] temp = new Committee[allCommittees.length * 2];
			for (int i = 0; i < allCommittees.length; i++) {
				temp[i] = allCommittees[i];
			}
			allCommittees = temp;
		}
		allCommittees[numOfCommittees++] = theCommittee;
		return true;
	}
	
	public boolean removeCommittee(Committee theCommittee) {
		for (int i = 0; i < numOfCommittees; i++) {
			if (allCommittees[i] != null && allCommittees[i].equals(theCommittee)) {
				for (int j = i; j < numOfCommittees - 1; j++) {
					allCommittees[j] = allCommittees[j + 1];
				}
				allCommittees[--numOfCommittees] = null;
				return true;
			}
		}
		return false;
	}

	public Committee[] getCommittees() {
		Committee[] result = new Committee[numOfCommittees];
		for (int i = 0; i < numOfCommittees; i++) {
			result[i] = allCommittees[i];
		}
		return result;
	}

	public boolean addArticles(String newArticle) {
        if (degree != eDegree.DOCTORATE && degree != eDegree.PROFESSOR) return false;
        if (newArticle == null) return false;
        for (int i = 0; i < numOfArticles; i++) {
            if (articles[i].equals(newArticle)) return false;
        }
        if (numOfArticles == articles.length) {
            String[] temp = new String[articles.length * 2];
            System.arraycopy(articles, 0, temp, 0, articles.length);
            articles = temp;
        }
        articles[numOfArticles++] = newArticle;
        return true;
    }
	
	public int getNumOfArticles() {
		return numOfArticles;
	}

	
	
	public boolean removeArticles(String theArticle) {
        if (degree != eDegree.DOCTORATE && degree != eDegree.PROFESSOR) return false;
        for (int i = 0; i < numOfArticles; i++) {
            if (articles[i].equals(theArticle)) {
                for (int j = i; j < numOfArticles - 1; j++) {
                    articles[j] = articles[j + 1];
                }
                articles[--numOfArticles] = null;
                return true;
            }
        }
        return false;
    }
	
	@Override
	public boolean equals(Object obj) {
	    if (this == obj) return true;
	    if (obj == null || getClass() != obj.getClass()) return false;

	    Lecturer other = (Lecturer) obj;

	    // השוואת מזהה, שם, תואר
	    if (this.id != other.id) return false;
	    if (!this.name.equals(other.name)) return false;
	    if (this.degree != other.degree) return false;
	    if (!this.degreeName.equals(other.degreeName)) return false;
	    if (this.salary != other.salary) return false;

	    // השוואת מחלקה
	    if (this.department == null) {
	        if (other.department != null) return false;
	    } else if (!this.department.equals(other.department)) return false;

	    // השוואת מאמרים
	    if (this.numOfArticles != other.numOfArticles) return false;
	    if (!java.util.Arrays.equals(this.articles, other.articles)) return false;

	    // השוואת כותרת פרופסור
	    if (this.professorTitleFrom == null) {
	        if (other.professorTitleFrom != null) return false;
	    } else if (!this.professorTitleFrom.equals(other.professorTitleFrom)) return false;

	    return true;
	}

	public String toString() {
        StringBuffer str = new StringBuffer();
        str.append("\nName = ").append(name)
           .append("\nId = ").append(id)
           .append("\nDegree = ").append(degree)
           .append("\nDegree name = ").append(degreeName)
           .append("\nSalary = ").append(salary)
           .append("\nDepartment = ").append(department != null ? department.getName() : "None");
        if (degree == eDegree.DOCTORATE || degree == eDegree.PROFESSOR) {
            str.append("\nArticles Published: ");
            for (int i = 0; i < numOfArticles; i++) {
                str.append("\n - ").append(articles[i]);
            }
        }
        if (degree == eDegree.PROFESSOR) {
            str.append("\nProfessorship granted by: ").append(professorTitleFrom);
        }
        return str.toString();
    }

}