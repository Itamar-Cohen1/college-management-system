package college_management_system_itamar_cohen;

public class LecturerAlreadyInCommitteeException extends Exception {
    public LecturerAlreadyInCommitteeException(String message) {
        super(message);
    }
}