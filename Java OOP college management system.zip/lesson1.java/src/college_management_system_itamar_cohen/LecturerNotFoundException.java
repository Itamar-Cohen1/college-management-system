package college_management_system_itamar_cohen;

public class LecturerNotFoundException extends Exception {
    public LecturerNotFoundException(String message) {
        super(message);
    }
}

