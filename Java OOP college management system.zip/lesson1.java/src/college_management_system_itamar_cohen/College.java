package college_management_system_itamar_cohen;

import college_management_system_itamar_cohen.Lecturer.eDegree;

public class College {
	public enum eCommitteStatus {
		succeed, failedLecturerUnqualified, failedLecturerNotExist, FailedLecturerAlreadyRegisterd,
		failedCommitteeNotExist, failedCommitteeAlreadyExist
	};

	private String nameOfCollege;
	private Department[] allDepartments;
	private int departmentCount;
	private Lecturer[] allLecturers;
	private int lecturerCount;
	private Committee[] allCommittees;
	private int committeeCount;

	public College(String nameOfcollege) {
		this.nameOfCollege = nameOfcollege;
		this.allDepartments = new Department[10];
		this.allLecturers = new Lecturer[10];
		this.allCommittees = new Committee[10];
		this.departmentCount = 0;
		this.lecturerCount = 0;
		this.committeeCount = 0;
	}

	public String getName() {
		return nameOfCollege;
	}

	public Lecturer[] getLecturers() {
		Lecturer[] result = new Lecturer[lecturerCount];
		for (int i = 0; i < lecturerCount; i++) {
			result[i] = allLecturers[i];
		}
		return result;
	}

	public Committee[] getCommittees() {
		Committee[] result = new Committee[committeeCount];
		for (int i = 0; i < committeeCount; i++) {
			result[i] = allCommittees[i];
		}
		return result;
	}

	public boolean addDepartment(String name, int numStudents) {
		if (departmentCount == allDepartments.length) {
			expandDepartments();
		}
		if (findDepartmentByName(name) != null) {
			return false;
		}

		allDepartments[departmentCount++] = new Department(name, numStudents);
		return true;
	}

	public boolean addLecturer(String name, int id, eDegree degree, String degreeName, double salary,String professorTitleFrom,String[] articles) {
		if (lecturerCount == allLecturers.length) {
			expandLecturers();
		}
		if (findLecturerByName(name) != null) {
			return false;
		}
		allLecturers[lecturerCount++] = new Lecturer(name, id, degree, degreeName, salary,professorTitleFrom,articles);
		return true;
	}

	public void addCommittee(String committeeName, String headOfCommitteeName)
	        throws CommitteeAlreadyExistsException, LecturerNotFoundException, LecturerUnqualifiedException {
	    
	    Lecturer l = findLecturerByName(headOfCommitteeName);
	    
	    if (findCommitteeByName(committeeName) != null) {
	        throw new CommitteeAlreadyExistsException("Committee with name '" + committeeName + "' already exists.");
	    }
	    
	    if (l == null) {
	        throw new LecturerNotFoundException("Lecturer '" + headOfCommitteeName + "' not found.");
	    }
	    
	    eDegree degree = l.getDegree();
	    if (degree != eDegree.DOCTORATE && degree != eDegree.PROFESSOR) {
	        throw new LecturerUnqualifiedException("Lecturer '" + l.getName() + "' is not qualified to head a committee.");
	    }

	    if (committeeCount == allCommittees.length) {
	        expandCommittees();
	    }

	    allCommittees[committeeCount++] = new Committee(committeeName, l);
	}


	public void setHeadOfCommittee(String lecturerName, String committeeName)
	        throws LecturerNotFoundException, CommitteeNotFoundException,
	               LecturerAlreadyInCommitteeException, LecturerUnqualifiedException {

	    Lecturer l = findLecturerByName(lecturerName);
	    Committee c = findCommitteeByName(committeeName);

	    if (l == null) {
	        throw new LecturerNotFoundException("Lecturer '" + lecturerName + "' not found.");
	    }

	    if (c == null) {
	        throw new CommitteeNotFoundException("Committee '" + committeeName + "' not found.");
	    }

	    if (l.equals(c.getHeadOfCommittee())) {
	        throw new LecturerAlreadyInCommitteeException("Lecturer '" + lecturerName + "' is already the head of the committee.");
	    }

	    eDegree degree = l.getDegree();
	    if (degree != eDegree.DOCTORATE && degree != eDegree.PROFESSOR) {
	        throw new LecturerUnqualifiedException("Lecturer '" + lecturerName + "' is not qualified to be head of a committee.");
	    }

	    c.setHeadOfCommittee(l); // Everything OK
	}


	public void assignLecturerToCommittee(String lecturerName, String committeeName) {
		Lecturer l = findLecturerByName(lecturerName);
		Committee c = findCommitteeByName(committeeName);
		if (l != null && c != null) {
			c.addLecturer(l);
		}
	}

	public void removeMemberFromCommittee(String lecturerName, String committeeName) {
		Lecturer l = findLecturerByName(lecturerName);
		Committee c = findCommitteeByName(committeeName);
		if (l != null && c != null) {
			c.removeLecturer(l);
		}
	}

	public void assignLecturerToDepartment(String lecturerName, String departmentName) {
		Lecturer l = findLecturerByName(lecturerName);
		Department d = findDepartmentByName(departmentName);
		if (l != null && d != null) {
			d.addLecturer(l);
		}
	}

	private void expandDepartments() {
		Department[] temp = new Department[allDepartments.length * 2];
		for (int i = 0; i < allDepartments.length; i++) {
			temp[i] = allDepartments[i];
		}
		allDepartments = temp;
	}

	private void expandLecturers() {
		Lecturer[] temp = new Lecturer[allLecturers.length * 2];
		for (int i = 0; i < allLecturers.length; i++) {
			temp[i] = allLecturers[i];
		}
		allLecturers = temp;
	}

	private void expandCommittees() {
		Committee[] temp = new Committee[allCommittees.length * 2];
		for (int i = 0; i < allCommittees.length; i++) {
			temp[i] = allCommittees[i];
		}
		allCommittees = temp;
	}

	public Lecturer findLecturerByName(String name) {
		for (int i = 0; i < lecturerCount; i++) {
			if (allLecturers[i].getName().equals(name)) {
				return allLecturers[i];
			}
		}
		return null;
	}

	public Department findDepartmentByName(String name) {
		for (int i = 0; i < departmentCount; i++) {
			if (allDepartments[i].getName().equals(name)) {
				return allDepartments[i];
			}
		}
		return null;
	}

	public Committee findCommitteeByName(String name) {
		for (int i = 0; i < committeeCount; i++) {
			if (allCommittees[i].getName().equals(name)) {
				return allCommittees[i];
			}
		}
		return null;
	}
	
	public double averageSalaryAllLecturersInTheCollege() {
        double result=0;
		Lecturer allLecturers[]=this.getLecturers();
		for (int i = 0; i < allLecturers.length; i++) {
			result =result+ allLecturers[i].getSalary();
		}
		result=result/allLecturers.length;
        return result;
	}
	
	public void compareTwoLecturersByNumberOfArticles(String lecturerName1, String lecturerName2) {
	    Lecturer lecturer1 = this.findLecturerByName(lecturerName1.trim());
	    Lecturer lecturer2 = this.findLecturerByName(lecturerName2.trim());

	    if (lecturer1 == null || lecturer2 == null) {
	        System.out.println("One or both lecturers not found.");
	        return;
	    }

	    if ((lecturer1.getDegree() != Lecturer.eDegree.DOCTORATE && lecturer1.getDegree() != Lecturer.eDegree.PROFESSOR) ||
	        (lecturer2.getDegree() != Lecturer.eDegree.DOCTORATE && lecturer2.getDegree() != Lecturer.eDegree.PROFESSOR)) {
	        System.out.println("Both lecturers must be DOCTORATE or PROFESSOR to compare articles.");
	        return;
	    }

	    int articles1 = lecturer1.getNumOfArticles();
	    int articles2 = lecturer2.getNumOfArticles();

	    System.out.println("Comparing " + lecturer1.getName() + " and " + lecturer2.getName() + ":");
	    if (articles1 > articles2) {
	        System.out.println(lecturer1.getName() + " has more articles (" + articles1 + " vs " + articles2 + ").");
	    } else if (articles2 > articles1) {
	        System.out.println(lecturer2.getName() + " has more articles (" + articles2 + " vs " + articles1 + ").");
	    } else {
	        System.out.println("Both have the same number of articles (" + articles1 + ").");
	    }
	}
	
	public int countArticlesInCommittee(Committee committee) {
	    int total = 0;
	    for (Lecturer lecturer : committee.getLecturers()) {
	        if (lecturer.getDegree() == Lecturer.eDegree.DOCTORATE || lecturer.getDegree() == Lecturer.eDegree.PROFESSOR) {
	            total += lecturer.getNumOfArticles();
	        }
	    }
	    return total;
	}

	public void compareTwoCommittees(String committeeName1, String committeeName2, int criteria) {
	    Committee committee1 = findCommitteeByName(committeeName1.trim());
	    Committee committee2 = findCommitteeByName(committeeName2.trim());

	    if (committee1 == null || committee2 == null) {
	        System.out.println("One or both committees not found.");
	        return;
	    }

	    switch (criteria) {
	        case 1:
	            // קריטריון 1 - מספר חברי סגל
	            int size1 = committee1.getLecturers().length;
	            int size2 = committee2.getLecturers().length;

	            System.out.println("Comparing committees by number of lecturers:");
	            if (size1 > size2) {
	                System.out.println(committee1.getName() + " has more lecturers (" + size1 + " vs " + size2 + ").");
	            } else if (size2 > size1) {
	                System.out.println(committee2.getName() + " has more lecturers (" + size2 + " vs " + size1 + ").");
	            } else {
	                System.out.println("Both committees have the same number of lecturers (" + size1 + ").");
	            }
	            break;

	        case 2:
	            // קריטריון 2 - מספר סה"כ מאמרים
	            int totalArticles1 = countArticlesInCommittee(committee1);
	            int totalArticles2 = countArticlesInCommittee(committee2);

	            System.out.println("Comparing committees by total number of articles:");
	            if (totalArticles1 > totalArticles2) {
	                System.out.println(committee1.getName() + " has more articles (" + totalArticles1 + " vs " + totalArticles2 + ").");
	            } else if (totalArticles2 > totalArticles1) {
	                System.out.println(committee2.getName() + " has more articles (" + totalArticles2 + " vs " + totalArticles1 + ").");
	            } else {
	                System.out.println("Both committees have the same number of articles (" + totalArticles1 + ").");
	            }
	            break;

	        default:
	            System.out.println("Invalid criteria. Use 1 for number of lecturers, 2 for total articles.");
	    }
	}

	public void duplicateCommittee(String originalCommitteeName) {
	    Committee original = findCommitteeByName(originalCommitteeName.trim());
	    if (original == null) {
	        System.out.println("Committee not found.");
	        return;
	    }

	    String newName = "new-" + original.getName();

	    // בדיקה אם כבר קיימת ועדה בשם הזה
	    if (findCommitteeByName(newName) != null) {
	        System.out.println("A committee with the name \"" + newName + "\" already exists.");
	        return;
	    }
	    
	    // הוספה לרשימת הוועדות של המכללה
	    try {
			this.addCommittee(newName, original.getHeadOfCommittee().getName());
		} catch (CommitteeAlreadyExistsException e) {

			e.printStackTrace();
		} catch (LecturerNotFoundException e) {

			e.printStackTrace();
		} catch (LecturerUnqualifiedException e) {

			e.printStackTrace();
		} 

	    // הוספת כל המרצים מהוועדה המקורית לוועדה החדשה
	    Lecturer[] originalLecturers = original.getLecturers();
	    for (Lecturer lecturer : originalLecturers) {
	        this.assignLecturerToCommittee(lecturer.getName(), newName);
	    }
	    
	    System.out.println("Committee duplicated successfully as \"" + newName + "\".");
	}


	public void fullDetailsOfAllLecturers() {
		String result="";
		Lecturer allLecturers[]=this.getLecturers();
		for (int i = 0; i < allLecturers.length; i++) {
			result =result+ allLecturers[i].toString();
		}
		System.out.println(result);
	}
		
	public void fullDetailsOfAllCommittees() {
		String result="";
		Committee allCommittees[]=this.getCommittees();
		for (int i = 0; i < allCommittees.length; i++) {
			result =result+ allCommittees[i].toString();
		}
		System.out.println(result);
	}
	
	public void printAllData() {
		System.out.println("=== Departments ===");
		for (int i = 0; i < departmentCount; i++) {
			System.out.println(allDepartments[i]);
			System.out.println();
		}

		System.out.println("=== Lecturers ===");
		for (int i = 0; i < lecturerCount; i++) {
			System.out.println(allLecturers[i]);
			System.out.println();
		}

		System.out.println("=== Committees ===");
		for (int i = 0; i < committeeCount; i++) {
			System.out.println(allCommittees[i]);
			System.out.println();
		}
	}

}