package college_management_system_itamar_cohen;

public class CommitteeAlreadyExistsException extends Exception {
    public CommitteeAlreadyExistsException(String message) {
        super(message);
    }
}
