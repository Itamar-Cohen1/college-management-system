package college_management_system_itamar_cohen;

public class CommitteeNotFoundException extends Exception {
    public CommitteeNotFoundException(String message) {
        super(message);
    }
}

